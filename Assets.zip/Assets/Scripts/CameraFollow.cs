﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    
    public int CameraMoveSpeed = 120;
    public GameObject CameraFollowObj;
    Vector3 FollowPOS;
    public float clampAngle = 50.0f;
    public float inputSensitivity = 150.0f;
    public GameObject CameraObj;
    public GameObject Player;
    public float camDistanceXToPlayer;
    public float camDistanceYToPlayer;
    public float camDistanceZToPlayer;
    public float mouseX;
    public float mouseY;
    public float finalInputX;
    public float finalInputY;
    public float smoothX;
    public float smoothY;

    private float rotY = 0f;
    private float rotX = 0f;
    private Vector3 offset;

    void Start()
    {
        offset = transform.position - Player.transform.position;
        Vector3 rot = transform.localRotation.eulerAngles;
        rotY = rot.y;
        rotX = rot.x;
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        
    }
    private void LateUpdate()
    {
        transform.position = Player.transform.position + offset;
    }


    void Update()
    {  
        mouseX  = Input.GetAxis("Mouse Y");
        mouseY = Input.GetAxis("Mouse X");

        rotY += mouseY * inputSensitivity * Time.deltaTime;
        rotX += mouseX * inputSensitivity * Time.deltaTime;

        rotX = Mathf.Clamp(rotX, -clampAngle, clampAngle);

        Quaternion localRotation = Quaternion.Euler(rotX, rotY, 0.0f);
        transform.rotation = localRotation;
    }
     private void CameraUpdater(){
        throw new NotImplementedException();
    }
     public void CamerUpdater()
    {
         
        Transform target = CameraFollowObj.transform;
        float step = CameraMoveSpeed * Time.deltaTime;
        transform.position = Vector3.MoveTowards (transform.position, transform.position, step);
    }
}
