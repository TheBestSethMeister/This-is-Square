﻿using UnityEngine;
using UnityEngine.UI;

public class GameOver : MonoBehaviour{

    private Text txt;
     

     public void Showtext()
    {
        txt = GetComponent<Text>();
        txt.text = "";
    }

    public void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag ("Bully"))
        {
        txt.text = "Game Over";
        }
        if (collision.gameObject.CompareTag("Win"))
        {
            txt.text = "Congrats";
        }
       
    }
}