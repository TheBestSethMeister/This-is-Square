﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotationMotion : MonoBehaviour
{
    public float Rotationspeed = 0f;
    private Rigidbody rb;

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
    }


    void FixedUpdate()
    {
        rb.AddTorque(0, Rotationspeed, 0);
    }
}
