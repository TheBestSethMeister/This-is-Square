﻿using UnityEngine;

public class Playermovement : MonoBehaviour
{
    
    [Range(1, 10)]
    public float jumpspeed;
    public float jumpforce;

    public float speed;
    [Range(1f, 2f)]
    public float hillspeed;
    public float throwheight = 0f;
    public float moveHorizontal;
    public float moveVertical;
    public float SprintSpeed;

    private Transform tf;
    private Playermovement pm;
    private Vector3 jump;
    private Rigidbody rb;
    private Transform cameraTransform;
    private Jumpcontrol jc;
    
    public bool onramp;
    public bool isGrounded;

    void Start()
    {
        onramp = false;
        tf = GetComponent<Transform>();
        jc = GetComponent<Jumpcontrol>();
        pm = GetComponent<Playermovement>();
        rb = GetComponent<Rigidbody>();
        jump = new Vector3(0.0f, 2.0f, 0f);
    }
    public void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ramp"))
        {
            onramp = false;
        }
    }
    public void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ramp") && onramp == false)
        { 
            onramp = true;
            isGrounded = true;
        }
        if (collision.gameObject.CompareTag("Bully"))
        {
            rb.AddForce(0, throwheight, 0);
            pm.enabled = false;
            rb.useGravity = false;
            jc.enabled = false;
            rb.angularDrag = 0f;
            rb.drag = 2f;
            FindObjectOfType<Gamemanager>().EndGame();
        }

        if (collision.gameObject.CompareTag("Ground"))
        {
            Update();
            isGrounded = true;
        } 
    }
    void Update()
    {
        Input.GetKey(KeyCode.LeftShift);
        Input.GetKey(KeyCode.Space);
        moveHorizontal = Input.GetAxisRaw("Horizontal");
        moveVertical = Input.GetAxisRaw("Vertical"); 
    }
    void FixedUpdate()
    {
 
         Vector3 movement = ((Camera.main.transform.forward * moveVertical) * Time.deltaTime) + ((Camera.main.transform.right * moveHorizontal) * Time.deltaTime);
        movement.y = 0f;
        rb.AddForce(movement * speed);

        if (Input.GetKey(KeyCode.LeftShift))
        {
            rb.AddForce(((movement * SprintSpeed) * Time.deltaTime) * (speed * Time.deltaTime), ForceMode.Force);
        }

        if(onramp == true)
        {
            
            rb.AddForce(((movement * hillspeed)) * (speed), ForceMode.Force);
            
        }
       
        if(tf.position.y < -1f)
        {
            FindObjectOfType<Gamemanager>().EndGame();
        }

        if (Input.GetKey(KeyCode.Space) && isGrounded == true)
        {
            
            GetComponent<Rigidbody>().velocity = Vector3.up * jumpspeed;
            isGrounded = false;
            rb.AddForce(jump * Time.deltaTime  * jumpforce *Time.deltaTime , ForceMode.Impulse);
        }      
    }
}