﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Gamemanager : MonoBehaviour
{
    
    public Text gO;
    public GameObject Gop;
    public float Restartdelay = 1f;
    bool GameHasEnded = false;


    private void Start()
    {
        gO.text = "Victory";
    }
    private void Awake()
    {
        Gop.SetActive(false);
    }

    public void EndGame()
    {
       

        if (GameHasEnded == false)
        {
            GameHasEnded = true;
            Debug.Log("Game Over");
            Invoke("Restart", Restartdelay);
            Invoke("Activate", 2f);
            gO.text = "Game Over";
        }
    }
    void Restart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
    void Activate()
    {
        Gop.SetActive(true);
    } 
}