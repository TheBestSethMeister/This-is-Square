﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Jumpcontrol : MonoBehaviour
{
    public float Fallmult = 2.5f;
    public float lowmult = 2f;

    Rigidbody rb;

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }

    private void Update()
    {
        if (rb.velocity.y < 0)
        {
            rb.velocity += Vector3.up * Physics.gravity.y * (Fallmult - 1) * Time.deltaTime;
        } else if(rb.velocity.y > 0 && !Input.GetKey(KeyCode.Space))
        {
            rb.velocity += Vector3.up * Physics.gravity.y * (lowmult - 1) * Time.deltaTime;
        }
    }
}
