﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class NextLvl : MonoBehaviour
{
    public Jumpcontrol jc;
    public Playermovement pm;
    public GameObject GOp;
    public Rigidbody rb;
    public float Delay;
    public float throwstrength;

    private void Start()
    {
        GOp.SetActive(false);
        
    }
    public void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Invoke("CompleteLevel", Delay);
        GOp.SetActive(true);

            rb.useGravity = false;
            pm.enabled = false;
            rb.AddForce(throwstrength, throwstrength, throwstrength);
            jc.enabled = false;
            rb.angularDrag = 0f;
        
        }
        
    }

    public void CompleteLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);

    }
}