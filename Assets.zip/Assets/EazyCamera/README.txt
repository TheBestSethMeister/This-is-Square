Eazy Camera Readme


To set up the Eazy Camera system:
1) Add the EzCamera component to a camera in the scene.
2) In the menu toolbar, use Eazy Camera > CreateCameraSettings to generate new settings, or use the existing settings in the project. 
3) Assign the Settings to the camera in your scene using the inspector
4) Assign the object that the camera should track to the proper field in the inspector.

Done! Your Eazy Camera system is now ready to use. 

From here you can adjust any values in the EzCameraSettings object to fine tune your camera, and the inspector on the camera to customize the functionality.

For any specific questions or bugs, email buttons@lintandbuttons.com