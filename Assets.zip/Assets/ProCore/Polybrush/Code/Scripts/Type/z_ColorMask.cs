namespace Polybrush
{
	public struct z_ColorMask
	{
		public bool r, g, b, a; 

		public z_ColorMask(bool r, bool g, bool b, bool a)
		{
			this.r = r;
			this.b = b;
			this.g = g;
			this.a = a;
		}
	}
}
	
